const DIFFICULTY = 4;

// in milliseconds
const MINE_RATE = 3000;

const INITIAL_BALANCE = 500;

const MINING_REWARD = 50;

module.exports = {
    DIFFICULTY,
    MINE_RATE,
    INITIAL_BALANCE,
    MINING_REWARD
}